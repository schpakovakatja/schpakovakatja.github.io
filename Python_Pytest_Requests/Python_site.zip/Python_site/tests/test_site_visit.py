import requests
import pytest

'''Переменные'''
URL = 'https://p-sergei-qa.github.io'


# Для запуска автотеста переходим в Минзурку Testing - Configure Python Tests - pytest - папка tests

'''Автотест 1 - проверяем статус ответа основной станицы сайта-визитки'''
def test_status_code_index(): 
    response = requests.get(url= f'{URL}/index.html')
    assert response.status_code == 200   #Теперь пишем саму проверку. Я утверждаю, что статус код этого запроса ==200

'''Автотест 1.1 - проверяем статус ответа страницы авторизации'''
def test_status_code_auth(): 
    response = requests.get(url= f'{URL}/auth/auth.html')
    assert response.status_code == 200   #Теперь пишем саму проверку. Я утверждаю, что статус код этого запроса ==200

'''Автотест 1.2 - проверяем статус ответа успешной страницы авторизации'''
def test_status_code_success(): 
    response = requests.get(url= f'{URL}/auth/success.html')
    assert response.status_code == 200   #Теперь пишем саму проверку. Я утверждаю, что статус код этого запроса ==200
     


'''Автотест 2 - сравнение на какой-то части ответа основной станицы сайта-визитки'''
def test_part_of_response_index(): 
    response_get = requests.get(url= f'{URL}/index.html')
    assert "Версия 3.0.2" in response_get.text # Проверяем, что текст ответа содержит строку "Версия 3.0.2"

'''Автотест 2.1 - сравнение на какой-то части ответа страницы авторизации'''
def test_part_of_response_auth(): 
    response_get = requests.get(url= f'{URL}/auth/auth.html')
    assert "Авторизация" in response_get.text # Проверяем, что текст ответа содержит строку "Авторизация"

'''Автотест 2.2 - сравнение на какой-то части ответа успешной страницы авторизации'''
def test_part_of_response_success(): 
    response_get = requests.get(url= f'{URL}/auth/success.html')
    assert "Вы успешно вошли в систему." in response_get.text # Проверяем, что текст ответа содержит строку "Вы успешно вошли в систему."